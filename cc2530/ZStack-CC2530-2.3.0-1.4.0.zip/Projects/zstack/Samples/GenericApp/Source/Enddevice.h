#ifndef ENDDEVICE_H
#define ENDDEVICE_H
#include <hal_types.h>
extern int8 readTemp(void);

#endif